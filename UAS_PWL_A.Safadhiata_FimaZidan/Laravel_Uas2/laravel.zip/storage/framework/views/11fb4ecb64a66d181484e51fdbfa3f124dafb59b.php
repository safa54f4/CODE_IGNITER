<?php
// dd($userinfo);
?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Data Mahasiswa</div>

                <div class="card-body">
                    <h4>Data Mahasiswa</h4>
                    <hr/>
                    <div class="row">
                        <div class="col-3">Nama Lengkap</div>
                        <div class="col-9"><?php echo e($userinfo->nama); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-3">Kota Lahir</div>
                        <div class="col-9"><?php echo e($userinfo->kota_lahir); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-3">Agama</div>
                        <div class="col-9"><?php echo e($userinfo->agama); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-3">Golongan Darah</div>
                        <div class="col-9"><?php echo e($userinfo->gol_darah); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-3">Nomor Telepon</div>
                        <div class="col-9"><?php echo e($userinfo->no_telp); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-3">NIK</div>
                        <div class="col-9"><?php echo e($userinfo->nik); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-3">Tanggal Lahir</div>
                        <div class="col-9"><?php echo e($userinfo->tgl_lahir); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-3">Jenis Kelamin</div>
                        <div class="col-9"><?php echo e($mahasiswa->getGender($userinfo->jenis_kelamin)); ?></div>
                    </div>
                    <div class="row">
                        <div class="col-3">Kelas</div>
                        <div class="col-9"><?php echo e($userinfo->kelas->nama); ?></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/gintoki/Pandora-Box/Project/Web/Kerjoan/Mas Polinema/Akademik/laravel/resources/views/mahasiswa/index.blade.php ENDPATH**/ ?>