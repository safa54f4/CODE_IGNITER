<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Jadwal Perkuliahan
                    <?php if($datauser->level_id == 1): ?>
                    <a href="<?php echo e(route("admin.tambah_jadwal")); ?>" class="btn btn-success float-right">Tambah Jadwal</a>
                    <?php endif; ?>
                </div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Hari</th>
                                <th>Jam</th>
                                <th>Kode MK</th>
                                <th>Mata Kuliah</th>
                                <th>Kelas</th>
                                <th>Semester</th>
                                <th>SKS</th>
                                <th>Dosen</th>
                                <?php if($datauser->level_id == 1): ?>
                                <th>Aksi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $krs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->hari); ?></td>
                                <td><?php echo e($item->jam); ?></td>
                                <td><?php echo e($item->kode_mk); ?></td>
                                <td><?php echo e($item->mata_kuliah); ?></td>
                                <td><?php echo e($item->kelas); ?></td>
                                <td><?php echo e($item->semester); ?></td>
                                <td><?php echo e($item->sks); ?></td>
                                <td><?php echo e($item->dosen); ?></td>
                                <?php if($datauser->level_id == 1): ?>
                                <td><a href="<?php echo e(route("admin.edit_jadwal", ["id" => $item->id])); ?>" class="btn btn-primary mr-2">Edit</a><a href="<?php echo e(route("admin.hapus_jadwal", ["id" => $item->id])); ?>" class="btn btn-danger">Hapus</a></td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\Web\Kerjoan\Mas Polinema\Akademik\laravel\resources\views/jadwal/jadwal.blade.php ENDPATH**/ ?>