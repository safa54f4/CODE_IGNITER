<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Hapus Jadwal
                </div>

                <div class="card-body">
                    Anda yakin menghapus jadwal Mata Kuliah <?php echo e($krs->mata_kuliah); ?> (<?php echo e($krs->kode_mk); ?>) pada hari <?php echo e($krs->hari); ?>  yang diajari oleh <?php echo e($krs->dosen); ?>?
                </div>
                <div class="card-footer">
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger">Hapus</button>
                    <a href="<?php echo e(route("admin.jadwal")); ?>" class="btn btn-secondary">Kembali</a>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\Web\Kerjoan\Mas Polinema\Akademik\laravel\resources\views/jadwal/hapus.blade.php ENDPATH**/ ?>