<?php

?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-body">
                    Selamat Datang di SIAKAD Polpolan
                </div>
                <div class="card-footer">
                    <?php if(!$hasapi): ?>
                        <a href="<?php echo e(route("api.login_form")); ?>" class="btn btn-primary">Login</a>
                    <?php else: ?>
                        <?php if($datauser->level_id == 1): ?>
                        <a href="<?php echo e(route("user.index")); ?>" class="btn btn-primary">Home</a>
                        <?php elseif($datauser->level_id == 2): ?>
                        <a href="<?php echo e(route("mahasiswa.index")); ?>" class="btn btn-primary">Home</a>
                        <?php endif; ?>
                    <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Project\Web\Kerjoan\Mas Polinema\Akademik\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>