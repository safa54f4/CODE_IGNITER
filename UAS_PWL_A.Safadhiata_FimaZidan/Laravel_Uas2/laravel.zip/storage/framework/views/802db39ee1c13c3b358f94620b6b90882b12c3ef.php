<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    Jadwal Perkuliahan
                    <a href="<?php echo e(route("admin.tambah_jadwal")); ?>" class="btn btn-success float-right">Tambah Jadwal</a>
                </div>

                <div class="card-body">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>No</th>
                                <th>Hari</th>
                                <th>Jam</th>
                                <th>Kode MK</th>
                                <th>Mata Kuliah</th>
                                <th>Kelas</th>
                                <th>Semester</th>
                                <th>SKS</th>
                                <th>Dosen</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $krs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->id); ?></td>
                                <td><?php echo e($item->hari); ?></td>
                                <td><?php echo e($item->pukul_awal); ?> - <?php echo e($item->pukul_akhir); ?></td>
                                <td><?php echo e($item->kode_mk); ?></td>
                                <td><?php echo e($item->mata_kuliah); ?></td>
                                <td><?php echo e($item->kelas->nama); ?></td>
                                <td><?php echo e($item->semester); ?></td>
                                <td><?php echo e($item->sks); ?></td>
                                <td><?php echo e($item->dosen); ?></td>
                                <td><a href="<?php echo e(route("admin.edit_jadwal", ["id" => $item->id])); ?>" class="btn btn-primary mr-2">Edit</a><a href="<?php echo e(route("admin.hapus_jadwal", ["id" => $item->id])); ?>" class="btn btn-danger">Hapus</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /run/media/gintoki/Pandora-Box/Project/Web/Kerjoan/Mas Polinema/Akademik/laravel/resources/views/jadwal/jadwal.blade.php ENDPATH**/ ?>