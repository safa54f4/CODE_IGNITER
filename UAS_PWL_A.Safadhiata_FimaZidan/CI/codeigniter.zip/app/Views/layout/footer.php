<script src="<?= base_url("/js/jquery-3.4.1.slim.min.js") ?>"></script>
<script src="<?= base_url("/js/popper.min.js") ?>"></script>
<script src="<?= base_url("/js/bootstrap.min.js") ?>"></script>
</body>

</html>